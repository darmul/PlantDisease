package com.example.tanaman

data class ProfileModel(
    val nama: String =""
)
