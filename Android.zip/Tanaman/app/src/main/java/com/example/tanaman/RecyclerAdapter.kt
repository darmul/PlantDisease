package com.example.tanaman

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.tanaman.databinding.RecycleLayoutBinding

class RecyclerAdapter(val context: Context, val historyModel: List<HistoryModel>): RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerAdapter.ViewHolder {
        val binding = RecycleLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerAdapter.ViewHolder, position: Int) {
        val history = historyModel[position]
        with(holder.binding){
            output1.text = context.getString(R.string.output_2, "Potato Early Light", history.output1, "%")
            output2.text = context.getString(R.string.output_2, "Potato Healthy", history.output2, "%")
            output3.text = context.getString(R.string.output_2, "Potato Late Light", history.output3, "%")
        }
    }

    override fun getItemCount(): Int {
        return historyModel.size
    }

    inner class ViewHolder(val binding: RecycleLayoutBinding): RecyclerView.ViewHolder(binding.root)

}