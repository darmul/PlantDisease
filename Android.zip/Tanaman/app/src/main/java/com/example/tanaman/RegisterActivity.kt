package com.example.tanaman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.tanaman.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class RegisterActivity : AppCompatActivity() {

    lateinit var binding: ActivityRegisterBinding
    lateinit var firestore: FirebaseFirestore
    lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth
        firestore = Firebase.firestore

        binding.signupBtn.setOnClickListener {
            val email = binding.emailEdt.text.toString()
            val sandi = binding.passwordEdt.text.toString()
            val nama = binding.namaEdt.text.toString()

            if (email.isBlank() || sandi.isBlank() || nama.isBlank() ){
                Toast.makeText(this, "Data Belum Lengkap", Toast.LENGTH_SHORT).show()
            } else if (sandi != binding.repasswordEdt.text.toString()) {
                Toast.makeText(this, "Kata sandi tidak sama", Toast.LENGTH_SHORT).show()
            } else {
                auth.createUserWithEmailAndPassword(email, sandi).addOnSuccessListener {
                    it.user?.uid?.let { it1 ->
                        val profileModel = ProfileModel(nama)
                        firestore.collection("Profile").document(it1).set(profileModel).addOnSuccessListener {
                            val intent = Intent(this, LoginActivity::class.java)
                            startActivity(intent)
                            finish()
                            Toast.makeText(this, "Register Success", Toast.LENGTH_SHORT).show()
                        }.addOnFailureListener {
                            Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                }.addOnFailureListener {
                    Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.toLoginTxt.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}