package com.example.tanaman

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.*
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.tanaman.databinding.ActivityCameraBinding
import com.example.tanaman.databinding.BottomsheetLayoutBinding
import com.example.tanaman.ml.PotateDisease
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.nio.ByteBuffer
import java.nio.ByteOrder

class CameraActivity : AppCompatActivity() {

    lateinit var binding: ActivityCameraBinding
    lateinit var cameraPermission: ActivityResultLauncher<String>
    var array = arrayOf("Potato Early Blight", "Potato Healthy", "Potato Late Blight")
    lateinit var imageCapture: ImageCapture

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        hideSystemBar()

        cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()){
            if (it){
                startCamera()
            } else {
                Toast.makeText(this, "camera cannot access", Toast.LENGTH_SHORT).show()
            }
        }

        if (checkPermission()){
            startCamera()
        } else {
            cameraPermission.launch(android.Manifest.permission.CAMERA)
        }

        binding.takePicImg.setOnClickListener {
            imageCapture.takePicture(ActivityCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback(){
                @SuppressLint("UnsafeOptInUsageError")
                override fun onCaptureSuccess(image: ImageProxy) {
                    var bitmap = image.image?.toBitmap()
                    bitmap = Bitmap.createScaledBitmap(bitmap!!, 224, 224, false)
                    if (bitmap != null) {
                        classificationProcess(bitmap, array)
                    }
                    image.close()
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.d("result25", exception.message, exception)
                    Toast.makeText(this@CameraActivity, "Error", Toast.LENGTH_SHORT).show()
                }
            })
        }

        binding.backBtn.setOnClickListener{
            finish()
        }
    }

    private fun checkPermission(): Boolean{
        return ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val processCameraProvider = cameraProviderFuture.get()
            processCameraProvider.unbindAll()

            val preview = Preview.Builder()
                .build()
            preview.setSurfaceProvider(binding.previewView.surfaceProvider)

            imageCapture = ImageCapture.Builder().build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                processCameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture
                )
            } catch (ex: Exception) {
                Log.d("cameraExc", ex.message, ex)
            }
        }, ActivityCompat.getMainExecutor(this))
    }

    private fun classificationProcess(bitmap: Bitmap, analisa: Array<String>) {
        val model = PotateDisease.newInstance(this)

        val inputFeature0 = TensorBuffer.createFixedSize(intArrayOf(1, 224, 224, 3), DataType.FLOAT32)

        val byteBuffer = ByteBuffer.allocateDirect(4 * 224 * 224 * 3)
        byteBuffer.order(ByteOrder.nativeOrder())

        val values = IntArray(224 * 224)

        try {
            bitmap.getPixels(values, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

            var pixel = 0

            for (i in 0..223) {
                for (j in 0..223) {
                    val value = values[pixel++]
                    byteBuffer.putFloat(((value shr 16) and 0xFF) * (1.0f / 255.0f))
                    byteBuffer.putFloat(((value shr 8) and 0xFF) * (1.0f / 255.0f))
                    byteBuffer.putFloat((value and 0xFF) * (1.0f / 255.0f))
                }
            }

            inputFeature0.loadBuffer(byteBuffer)

            val outputs = model.process(inputFeature0)
            val outputFeature0 = outputs.outputFeature0AsTensorBuffer

            val conviction = outputFeature0.floatArray

            createBottomSheet(analisa, conviction)
            saveDataToDatabase(conviction)

        } catch (e: Exception){
            e.printStackTrace()
        }
        model.close()
    }


    fun Image.toBitmap(): Bitmap {
        val buffer = planes[0].buffer
        buffer.rewind()
        val bytes = ByteArray(buffer.capacity())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun createBottomSheet(output1: Array<String>, conviction: FloatArray){
        val dialog = BottomSheetDialog(this)
        val inBinding = BottomsheetLayoutBinding.inflate(layoutInflater)
        dialog.setContentView(inBinding.root)

        inBinding.output1.text = getString(R.string.output, output1[0], (conviction[0] * 100).toInt(), "%")
        inBinding.output2.text = getString(R.string.output, output1[1], (conviction[1] * 100).toInt(), "%")
        inBinding.output3.text = getString(R.string.output, output1[2], (conviction[2] * 100).toInt(), "%")

        dialog.show()
    }

    private fun saveDataToDatabase(conviction: FloatArray){
        val firestore = Firebase.firestore
        val historyModel = HistoryModel(System.currentTimeMillis(),"${(conviction[0]*100).toInt()}", "${(conviction[1]*100).toInt()}", "${(conviction[2]*100).toInt()}")
        firestore.collection("Riwayat Pemindaian").document().set(historyModel).addOnSuccessListener {
            return@addOnSuccessListener
        }.addOnFailureListener {
            return@addOnFailureListener
        }
    }

    private fun hideSystemBar(){
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).let {
            it.hide(WindowInsetsCompat.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
}