package com.example.tanaman

data class HistoryModel(
    val id: Long = 0,
    val output1: String = "",
    val output2: String = "",
    val output3: String = ""
)
